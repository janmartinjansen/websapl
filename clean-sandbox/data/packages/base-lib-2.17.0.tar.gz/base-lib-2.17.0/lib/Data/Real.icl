implementation module Data.Real

import StdEnv

import Data.Array
import Data.Func
import Data.List

// https://floating-point-gui.de/errors/comparison/
approximatelyEqual :: !Real !Real !Real -> Bool
approximatelyEqual epsilon a b
	| a == b
		= True
	| a == 0.0 || b == 0.0 || abs a + abs b < LowestReal
		= abs (a - b) < epsilon*LowestReal
	| otherwise
		= abs (a - b) / min (abs a + abs b) LargestReal < epsilon

printRealWithDecimals :: !Int !Real -> String
printRealWithDecimals decimals r = formatReal decimals ?None '.' ?None r

formatReal :: !Int !(?(!Int, !Char)) !Char !(?Char) !Real -> String
formatReal decimals intalign decsep thousandsep r
	// First we move the desired decimals left of the .
	# shifted = r * 10.0 ^ (toReal decimals)
	// Call toInt to round our real (rounds to nearest integer according to the processor's current floating point
	// rounding method) and convert it to a string.
	# shifted_string = toString $ toInt shifted
	// We might have lost leading and trailing zeros during our conversion to string. In particular, any string with
	// leading zeros will lose those leading zeros. This can lead to ".4" where "0.004" might have been the desired
	// output. To account for this, we add zeros to the beginning of the string to reach the desired length. repeatn
	// will return [] when our number is negative.
	# shifted_string =
		(toString $ repeatn (decimals + 1 - size shifted_string) '0') +++
		shifted_string +++
		(toString $ repeatn (~decimals) '0')
	// Take the portion before and after the decimal, they are finally concatenated
	# int_part  = shifted_string % (0, size shifted_string - decimals - 1)
	# frac_part = shifted_string % (size shifted_string - decimals, size shifted_string - 1)
	// Pad the number to the required amount of digits before the decimal separator
	# int_part = case intalign of
		?Just (intdigits, padchar) = (toString $ repeatn (intdigits - size int_part) padchar) +++ int_part
		?None = int_part
	// Separate the integer and fractional parts into thousands
	# (int_part, frac_part) = case thousandsep of
		?Just sep = (reverseArr (sep3 sep (reverseArr int_part)), sep3 sep frac_part)
		?None     = (int_part, frac_part)
	// Do not include the decimal separator when we output no decimals
	| decimals <= 0 = int_part
	= concatArr3 int_part (toString decsep) frac_part
where
	//* Separate the 3-character groups of this `str` with the character `sep`
	sep3 :: !Char !String -> String
	sep3 sep str = concatArr (intersperse (toString sep) (group3 str))

	//* Turn a string into a list of its 3-character groups
	group3 :: !String -> [String]
	group3 str = foldrArrWithKey group3` [""] str
	where
		group3` :: !Int !Char ![String] -> [String]
		group3` i c [group:rest]
		| i rem 3 == 0 && i > 0 = ["",(toString c +++ group):rest]
		| otherwise             = [(toString c +++ group):rest]
