implementation module Data.Func

from StdFunc import const, o
import _SystemStrictLists

seqSt :: !(a .st -> .st) ![a] !.st -> .st
seqSt f l st = SeqSt f l st

SeqSt :: !(a .st -> .st) !(l a) !.st -> .st | List l a
SeqSt f [|] st = st
SeqSt f [|x:xs] st = SeqSt f xs (f x st)

mapSt :: !(a .st -> (b,.st)) ![a] !.st -> (![b],.st)
mapSt f l st = MapSt f l st

MapSt :: !(a .st -> (b, .st)) !(l a) !.st -> (!(l b), .st) | List l a & List l b
MapSt f [|] st = ([|], st)
MapSt f [|x:xs] st
	# (y, st) = f x st
	# (ys, st) = MapSt f xs st
	= ([|y:ys], st)

fix :: !(a -> a) -> a
fix f = let x = f x in x

hyperstrict :: !.a -> .a
hyperstrict a = code {
		push_a 0
		.d 1 0
		jsr _eval_to_nf
		.o 0 0
	}
