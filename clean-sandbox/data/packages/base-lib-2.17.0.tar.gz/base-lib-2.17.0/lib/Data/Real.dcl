definition module Data.Real

/**
 * @property-bootstrap
 *   import StdEnv, Text.GenPrint, Gast.Gen
 */

from System._Architecture import IF_INTEL
from StdInt import IF_INT_64_OR_32

/**
 * Compile-time check whether the x86 extended precision format is used for
 * intermediate values.
 */
IF_INTERMEDIATE_80BIT_REAL_PRECISION yes no :== IF_INTEL (IF_INT_64_OR_32 no yes) no

LargestReal    :== 1.7976931348623157E+308
/**
 * Smallest normalized 64 bit real > 0.0
 */
LowestReal     :== 2.2250738585072014E-308
Epsilon        :== 2.220446049250313E-16
Epsilon80      :== 1.08420217248550443E-19

/**
 * Compare two numbers with a given epsilon (error margin).
 *
 * The value of epsilon depends on the application.
 *
 * With a sensible epsilon (non-NaN and non-Infinity), Infinity values are only
 * approximately equal to the same infinity value, and NaN values are not
 * approximately equal to any value (including NaN).
 *
 * @param epsilon
 * @param first number
 * @param second number
 * @result equality
 *
 * @property symmetry: A.e :: Real; a :: Real; b :: Real:
 *   approximatelyEqual e a b =.= approximatelyEqual e b a
 * @property non-NaN values are equal to themselves: A.e :: Real; a :: Real:
 *   not (isNaN a) ==> approximatelyEqual e a a
 * @property NaN is not equal to anything: A.e :: Real; a :: Real:
 *   not (approximatelyEqual e a NaN)
 */
approximatelyEqual :: !Real !Real !Real -> Bool

/**
 * Pretty print real with given number of decimals
 * @param The number of decimals
 * @param The real to be printed
 */
printRealWithDecimals :: !Int !Real -> String

/**
 * Format a real with a given number of fractional digits, minimum integer digits and optional thousand separator.
 * @param The number of fractional digits. If negative, the output is a rounded integer without the decimal separator.
 * @param An optional minimum number of digits before the decimal separator, and the padding character
 *        (e.g. (2, '0') for "01.5", (2, ' ') for " 1.5")
 * @param The decimal separator character (usually '.'). Only used if the number of fractional digits is > 0.
 * @param An optional thousand separator character. If provided, the integer and fractional parts are separated into
 *        groups of three digits with this separator (e.g. (?Just ' ') for "1 000.0").
 * @param The real to be formatted
 */
formatReal :: !Int !(?(!Int, !Char)) !Char !(?Char) !Real -> String
